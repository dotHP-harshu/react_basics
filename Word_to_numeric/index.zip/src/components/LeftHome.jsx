import React from "react";
import { FaArrowRightLong } from "react-icons/fa6";

function LeftHome({ setIsShowingRightHome }) {
  return (
    <div className="w-full flex flex-col items-center justify-center gap-3">
      <h1 className="lg:text-4xl max-sm:text-2xl font-bold text-center">
        Word to Number converter
      </h1>
      <p className="lg:text-lg max-sm:text-base text-center">
        This is a fun project. But I learn a lot of logic via this project.
      </p>
      <button
        onClick={() => {
          setIsShowingRightHome(true);
        }}
        className="border-none outline-none text-base w-10 h-10 flex items-center justify-center bg-[#233838] text-center text-white rounded-full cursor-pointer"
      >
        <FaArrowRightLong />
      </button>
    </div>
  );
}

export default LeftHome;
